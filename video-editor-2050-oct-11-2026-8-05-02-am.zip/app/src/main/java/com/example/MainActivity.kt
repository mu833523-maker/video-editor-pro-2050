package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.example.ui.EditorScreen
import com.example.ui.HomeScreen
import com.example.ui.LoginScreen
import com.example.ui.theme.DarkCosmic
import com.example.ui.theme.VideoEditorTheme
import com.google.firebase.Firebase
import com.google.firebase.auth.auth

enum class Screen {
    LOGIN,
    HOME,
    EDITOR
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            VideoEditorTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = DarkCosmic
                ) {
                    val initialScreen = remember {
                        if (Firebase.auth.currentUser != null) Screen.HOME else Screen.LOGIN
                    }
                    var currentScreen by remember { mutableStateOf(initialScreen) }

                    // Smooth TikTok/CapCut-like slide and fade transitions (250ms easeInOut)
                    AnimatedContent(
                        targetState = currentScreen,
                        transitionSpec = {
                            if (targetState.ordinal > initialState.ordinal) {
                                (slideInHorizontally(
                                    initialOffsetX = { fullWidth -> fullWidth },
                                    animationSpec = tween(250, easing = FastOutSlowInEasing)
                                ) + fadeIn(
                                    animationSpec = tween(250, easing = FastOutSlowInEasing)
                                )).togetherWith(
                                    slideOutHorizontally(
                                        targetOffsetX = { fullWidth -> -fullWidth / 4 },
                                        animationSpec = tween(250, easing = FastOutSlowInEasing)
                                    ) + fadeOut(
                                        animationSpec = tween(250, easing = FastOutSlowInEasing)
                                    )
                                )
                            } else {
                                (slideInHorizontally(
                                    initialOffsetX = { fullWidth -> -fullWidth / 4 },
                                    animationSpec = tween(250, easing = FastOutSlowInEasing)
                                ) + fadeIn(
                                    animationSpec = tween(250, easing = FastOutSlowInEasing)
                                )).togetherWith(
                                    slideOutHorizontally(
                                        targetOffsetX = { fullWidth -> fullWidth },
                                        animationSpec = tween(250, easing = FastOutSlowInEasing)
                                    ) + fadeOut(
                                        animationSpec = tween(250, easing = FastOutSlowInEasing)
                                    )
                                )
                            }
                        },
                        label = "screen_navigation_transition"
                    ) { screen ->
                        when (screen) {
                            Screen.LOGIN -> {
                                LoginScreen(
                                    onLoginSuccess = {
                                        currentScreen = Screen.HOME
                                    },
                                    onContinueAsGuest = {
                                        currentScreen = Screen.HOME
                                    }
                                )
                            }
                            Screen.HOME -> {
                                HomeScreen(
                                    onNavigateToEditor = {
                                        currentScreen = Screen.EDITOR
                                    },
                                    onNavigateToLogin = {
                                        currentScreen = Screen.LOGIN
                                    }
                                )
                            }
                            Screen.EDITOR -> {
                                EditorScreen(
                                    onBack = {
                                        currentScreen = Screen.HOME
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
